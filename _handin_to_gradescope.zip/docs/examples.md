# Real World Examples & Research

## Task 1: Read A5 and Identify Difficult Parts

Read the A5 handout in detail and begin working on it. Then identify and describe three parts of the assignment you understand the least. Below describe:

1. Replace <title> with the name of the part.
2. What concepts from this part do you understand?
3. How and why is it difficult to understand?

### Part 1: <title>


### Part 2: <title>


### Part 3: <title>


## Task 2: Two Real-World Examples / Analogies

For the concept of "Dynamic Memory Allocation" and one other technical concept from A5, find real-world examples or an analogy to explain it. Think of this as a practice for the final presentation in this class. Include your source from where you found your real-world example or an analogy.

### Concept 1: Dynamic Memory Allocation



### Concept 2: <title>


