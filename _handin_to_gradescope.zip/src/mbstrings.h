#ifndef MBSTRINGS_H
#define MBSTRINGS_H

#include <stddef.h>

size_t mbslen(const char* bytes);

#endif
